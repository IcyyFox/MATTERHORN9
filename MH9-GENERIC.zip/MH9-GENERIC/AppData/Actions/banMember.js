module.exports = {
  category: "Members",
  data: {
    name: "Ban Member",
  },
  UI: [
    {
      element: "memberInput",
      storeAs: "member",
      name: "Member"
    },
    "-",
    {
      element: "input",
      storeAs: "reason",
      name: "Reason",
      placeholder: "Optional"
    }
  ],
  compatibility: ["Any"],
  subtitle: (values, constants) => {
    return `Member: ${constants.user(values.member)} - Reason: ${values.reason}`
  },
  
  async run(values, msg, client, bridge) {
    let guild = bridge.guild;
    
    let user = await bridge.getUser(values.member)
    let member = await user.member;
    member = member.id;
    
    if (values.reason.trim() == "") {
      guild.createBan(member);
    } else {
      guild.createBan(member, {
        reason: bridge.transf(values.reason),
      });
    }
  },
};
