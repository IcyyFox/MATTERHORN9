const { Member } = require("oceanic.js");

module.exports = {
  category: "Members",
  data: {
    name: "Get Member Info",
  },
  UI: [
    {
      element: "member",
      storeAs: "member",
      name: "Member"
    },
    "-",
    {
      element: "halfDropdown",
      storeAs: "get",
      name: "Get",
      choices: [
        {
          name: "Nickname"
        },
        {
          name: "Name"
        },
        {
          name: "Username"
        },
        {
          name: "Guild"
        },
        {
          name: "Avatar URL"
        },
        {
          name: "Banner URL"
        },
        {
          name: "ID"
        },
        {
          name: "Timeout End Timestamp"
        },
        {
          name: "Status Text"
        },
        {
          name: "Status"
        },
        {
          name: "Accent Color"
        },
        {
          name: "Joined At Timestamp"
        },
        {
          name: "Member Is Timed Out?"
        },
        {
          name: "Voice Channel"
        },
        {
          name: "Highest Role"
        },
        {
          name: "Boosting Started At Timestamp"
        }
      ]
    },
    "-",
    {
      element: "store",
      name: "Store As",
      storeAs: "store"
    }
  ],

  compatibility: ["Any"],

  subtitle: (values, constants) => {
    return `${values.get} of ${constants.user(values.member)} - Store As: ${constants.variable(values.store)}`
  },

  async run(values, message, client, bridge) {
    let user = await bridge.getUser(values.member);
    
    /**
     * @type {Member}
     */
    let member = await user.member;
    
    let output;

    switch (values.get) {
      case "Nickname":
        output = member.nick || user.globalName;
        break;

      case "Name":
        output = user.globalName;
        break;

      case "Username":
        output = user.username;
        break;

      case "Avatar URL":
        output = member.avatarURL() || user.avatarURL();
        break;

      case "Guild":
        output = member.guild;
        break;

      case "ID":
        output = member.id;
        break;

      case "Timeout End Timestamp":
        output = member.communicationDisabledUntil?.getTime();
        break;

      case "Status Text":
        try {
          output = user.presence.activities.filter(activity => activity.type == 4 && activity.name == 'Custom Status')[0].state;          
        } catch (err) {
          output = ''
        }
        break

      case "Discriminator":
        output = user.discriminator;
        break

      case "Member Is Timed Out?":
        output = member.communicationDisabledUntil ? true : false
        break
      
      case "Joined At Timestamp":
        output = member.joinedAt.getTime()
        break

      case "Voice Channel":
        output = await (client.getChannel(member.voiceState.channelID) || await client.rest.channels.get(member.voiceState.channelID));
        break

      case "Banner URL":
          let restUser = await client.rest.users.get(member.id);
          output = restUser.bannerURL();
        break

      case "Accent Color":
        output = user.accentColor;
        break

      case "Highest Role":
        let highestRole;
        member.roles.forEach(roleID => {
          let rolePosition = member.guild.roles.get(roleID).position;
          let role = member.guild.roles.get(roleID);
          
          if (highestRole?.position < rolePosition || !highestRole) {
            highestRole = role
          }
        });
        
        output = highestRole;
        break

      case "Status":
        if (member.presence?.activities[0]) {
          output = member.presence.status;
        } else {
          output = '';
        }
        break

      case "Boosting Started At Timestamp":
        output = member.premiumSince
        break
    }

    bridge.store(values.store, output)
  },
};
