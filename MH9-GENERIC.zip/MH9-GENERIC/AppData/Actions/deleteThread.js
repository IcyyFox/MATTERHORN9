module.exports = {
  data: {
    name: "Delete Thread",
  },
  category: "Threads",
  UI: [
    {
      element: "var",
      storeAs: "thread",
      name: "Thread Variable"
    }
  ],

  compatibility: ["Any"],
  subtitle: (data) => {return `Thread Variable: ${data.thread.value}`},

  async run(values, message, client, bridge) {
    let thread = await bridge.get(values.thread);

    await thread.delete()
  },
};