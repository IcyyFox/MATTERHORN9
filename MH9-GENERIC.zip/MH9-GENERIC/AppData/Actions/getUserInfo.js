module.exports = {
  data: {
    name: "Get User Info",
  },
  category: "Users",
  UI: [
    {
      element: "userInput",
      storeAs: "user"
    },
    "-",
    {
      element: "halfDropdown",
      storeAs: "get",
      name: "Get",
      choices: [
        {
          name: "Name"
        },
        {
          name: "Username"
        },
        {
          name: "Avatar URL"
        },
        {
          name: "ID"
        },
        {
          name: "Discriminator"
        },
        {
          name: "Banner URL"
        },
        {
          name: "Account Creation Timestamp"
        },
        {
          name: "Accent Color"
        },
        {
          name: "Is Bot?"
        },
        {
          name: "Flags"
        }
      ]
    },
    "-",
    {
      element: "store",
      name: "Store As",
      storeAs: "store"
    }
  ],

  compatibility: ["Any"],

  subtitle: (values, constants) => {
    return `${values.get} of ${constants.user(values.user)} - Store As: ${constants.variable(values.store)}`
  },

  async run(values, message, client, bridge) {
    var user = await bridge.getUser(values.user);

    let output;

    switch (values.get) {
      case "Name":
        output = user.globalName || user.username;
        break;

      case "Username":
        output = user.username;
        break;

      case "Avatar URL":
        output = await user.avatarURL();
        break;

      case "ID":
        output = user.id;
        break;
      
      case "Discriminator":
        output = user.discriminator;
        break;
      
      case "Account Creation Timestamp":
        output = user.createdAt.getTime();
        break;
      
      case "Accent Color":
        output = (await client.rest.users.get(user.id)).accentColor.toString(16);
        break
      
      case "Banner URL":
        let restUser = await client.rest.users.get(user.id);
        output = restUser.bannerURL();
        break

      case "Is Bot?":
        output = user.bot;
        break

      case "Flags":
        output = user.flags;
        break
    }

    bridge.store(values.store, output)
  },
};
