module.exports = {
  category: "Emoji",
  data: { name: "Get Emoji Info" },
  UI: [
    {
      element: "variable",
      name: "Emoji",
      storeAs: "emoji"
    },
    "-",
    {
      element: "dropdown",
      name: "Get",
      storeAs: "get",
      choices: [
        {
          name: "Name"
        },
        {
          name: "ID"
        },
        {
          name: "Is Animated?"
        },
        {
          name: "Requires Colons?"
        },
        {
          name: "Available?"
        },
        {
          name: "Image URL"
        }
      ]
    },
    "-",
    {
      element: "store",
      storeAs: "store"
    }
  ],
  subtitle: (values, constants) => {
    return `${values.get} of ${constants.variable(values.emoji)} -  Store As ${constants.variable(values.store)}`
  },
  async run(values, message, client, bridge) {
    let emoji = bridge.get(values.emoji);
    let output;

    switch (values.get) {
      case "Name":
        output = emoji.name
        break
    
      case "ID":
        output = emoji.id
        break
    
      case "Is Animated?":
        output = emoji.animated
        break

      case "Requires Colons?":
        output = emoji.requireColons
        break

      case "Available?":
        output = emoji.available
        break

      case "Author":
        output = emoji.user
        break

      case "Image URL":
        output = `https://cdn.discordapp.com/emojis/${emoji.id}.png?size=512&quality=lossless`
        break
    }

    bridge.store(values.store, output)
  },
};
