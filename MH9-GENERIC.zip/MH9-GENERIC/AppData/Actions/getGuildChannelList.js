module.exports = {
category: "Channels",
  data: { name: "Get Guild Channels List" },
  UI: [
    {
      element: "halfDropdown",
      name: "Get List Of Guild Channels",
      storeAs: "get",
      choices: [
        {
          name: "IDs"
        },
        {
          name: "Variables"
        },
        {
          name: "Names"
        }
      ]
    },
    "-",
    {
      element: "storage",
      name: "Store List As",
      storeAs: "store"
    },
  ],

  compatibility: ["Any"],
  subtitle: (values, constants) => {
    return `Store Channel ${values.get} As ${constants.variable(values.store)}`
  },
  
  async run(values, interaction, client, bridge) {
    let output = [];
    let channels = await bridge.guild.getChannels({limit: 500})
    for (let channel of channels) {
      if (channel.type != 4) {
        if (values.get == "IDs") {
          output.push(channel.id);
        } else if (values.get == "Variables") {
          output.push(channel);
        } else {
          output.push(channel.name);
        }
      }
    }

    bridge.store(values.store, output)
  },
};
