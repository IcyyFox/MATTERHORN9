module.exports = {
  category: "Channels",
  data: {
    name: "Get Forum Info",
  },
  UI: [
    {
      element: "channelInput",
      storeAs: "channel",
      excludeUsers: true
    },
    "-",
    {
      element: "halfDropdown",
      storeAs: "get",
      name: "Get",
      choices: [
        {
          name: "Name"
        },
        {
          name: "URL"
        },
        {
          name: "ID"
        },
        {
          name: "Forum Tag List"
        },
        {
          name: "Rules"
        },
        {
          name: "Guild"
        },
        {
          name: "Category"
        },
        {
          name: "Creation Date"
        },
        {
          name: "Is NSFW?"
        },
        {
          name: "Post Creation Slowmode (Seconds)"
        },
        {
          name: "Default Post Slowmode (Seconds)"
        },
        {
          name: "Position"
        }
      ]
    },
    "-",
    {
      element: "storage",
      storeAs: "store"
    }
  ],
  compatibility: ["Any"],
  
  subtitle: (values, constants) => {
    return `${values.get} of ${constants.channel(values.channel)} - Store As: ${constants.variable(values.store)}`
  },
    async run(values, message, client, bridge) {
    let channel = await bridge.getChannel(values.channel)

    let output;
    switch (values.get) {
      case "Name":
        output = channel.name;
        break;
      case "URL":
        if (channel.guild) {
          output = `https://discord.com/channels/${channel.guild.id}/${channel.id}`;
        } else {
          output = `https://discord.com/channels/@me/${channel.recipient.id}`;
        }
        break;
      case "Rules":
        output = channel.topic || "";
        break;
      case "ID":
        output = channel.id;
        break;
      case "Guild":
        output = channel.guild
        break;
      case "Category":
        output = channel.parent
        break;
      case "Creation Date":
        output = channel.createdAt.getTime()
        break
      case "Is NSFW?":
        output = channel.nsfw;
        break
      case "Post Creation Slowmode (Seconds)":
        output = channel.rateLimitPerUser;
        break
      case "Default Post Slowmode (Seconds)":
        output = channel.defaultThreadRateLimitPerUser;
        break
      case "Position":
        output = channel.position;
        break
      case "Forum Tag List":
        output = channel.availableTags;
        break
    }

    bridge.store(values.store, output)
  },
};
