const { Guild } = require("oceanic.js");
module.exports = {
  data: {
    name: "Get Guild Info",
  },
  category: "Guilds",
  UI: [
    {
      element: "halfDropdown",
      name: "Get",
      storeAs: "get",
      choices: [
        {
          name: "Name"
        },
        {
          name: "Icon URL"
        },
        {
          name: "Member Count"
        },
        {
          name: "Human Count"
        },
        {
          name: "Bot Count"
        },
        {
          name: "Approximate Online Count"
        },
        {
          name: "Owner"
        },
        {
          name: "ID"
        },
        {
          name: "MFA Required"
        },
        {
          name: "Boosts"
        },
        {
          name: "Boost Level"
        },
        {
          name: "Description"
        },
        {
          name: "Banner URL"
        },
        {
          name: "Discovery Splash URL"
        },
        {
          name: "Invite Splash URL"
        },
        {
          name: "Webhook List"
        },
        {
          name: "Banned Users List"
        },
        {
          name: "Emoji List"
        },
        {
          name: "Invite List"
        },
        {
          name: "AFK Channel"
        },
        {
          name: "Creation Date"
        }
      ]
    },
    "-",
    {
      element: "store",
      storeAs: "store"
    }
  ],

  compatibility: ["Any"],
  subtitle: (data, constants) => {
    return `Get ${data.get} - Store As ${constants.variable(data.store)}`
  },

  async run(values, message, client, bridge) {
    let output;
    
    
    /**
     * @type {Guild}
     */
    let guild = bridge.guild;

    switch (values.get) {
      case "Name":
        output = guild.name;
        break;
      case "Icon URL":
        output = guild.iconURL();
        break;
      case "Member Count":
        output = guild.memberCount;
        break;
      case "Human Count":
        output = (await require('./getGuildMembersList').getMembers(bridge)).filter(m => !m.bot).length;
        break;
      case "Bot Count":
        output = (await require('./getGuildMembersList').getMembers(bridge)).filter(m => m.bot).length;
        break;
      case "Approximate Online Count":
        output = guild.approximatePresenceCount;
        break;
      case "Owner":
        let guildOwner = guild.ownerID;
        let ownerUser = client.users.get(guildOwner) || (await client.rest.users.get(guildOwner));

        output = ownerUser;
        break;
      
      case "Boost Level":
        output = guild.premiumTier;
        break

      case "Description":
        output = guild.description;
        break

      case "ID":
        output = guild.id;
        break
      
      case "Boosts":
        output = guild.premiumSubscriptionCount;
        break

      case "MFA Required":
        output = guild.mfaLevel ? true : false
        break

      case "Banner URL":
        output = guild.bannerURL()
        break
      
      case "Discovery Splash URL":
        output = guild.discoverySplashURL();
        break

      case "Invite Splash URL":
        output = guild.splashURL();
        break

      case "Webhook List":
        output = await guild.getWebhooks();
        break
      
      case "Banned Users List":
        output = (await guild.getBans({limit: Infinity})).map(ban => ban.user)
        break

      case "Emoji List":
        output = (await guild.getEmojis());
        break

      case "Invite List":
        output = (await guild.getInvites())
        break

      case "AFK Channel":
        output = guild.afkChannel;
        break

      case "AFK Timeout (Seconds)":
        output = guild.afkTimeout;
        break

      case "Creation Date":
        output = guild.createdAt.getTime();
        break
    }

    bridge.store(values.store, output)
  },
};
