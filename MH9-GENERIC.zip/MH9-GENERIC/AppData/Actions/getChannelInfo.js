module.exports = {
  category: "Channels",
  data: {
    name: "Get Channel Info",
  },
  UI: [
    {
      element: "channelInput",
      storeAs: "channel",
      excludeUsers: true
    },
    "-",
    {
      element: "halfDropdown",
      storeAs: "get",
      name: "Get",
      choices: [
        {
          name: "Channel Name"
        },
        {
          name: "Channel URL"
        },
        {
          name: "Channel ID"
        },
        {
          name: "Channel Topic"
        },
        {
          name: "Channel Guild"
        },
        {
          name: "Channel Category"
        },
        {
          name: "Channel Creation Date"
        },
        {
          name: "Channel Is NSFW?"
        },
        {
          name: "Channel Slowmode (Seconds)"
        },
        {
          name: "Channel Position"
        },
        {
          name: "Channel Type"
        },
        {
          name: "Webhook List"
        }
      ]
    },
    "-",
    {
      element: "storage",
      storeAs: "store"
    }
  ],
  compatibility: ["Any"],
  
  subtitle: (values, constants) => {
    return `${values.get} of ${constants.channel(values.channel)} - Store As: ${constants.variable(values.store)}`
  },
  
  async run(values, message, client, bridge) {
    let channel = await bridge.getChannel(values.channel)

    let output;
    switch (values.get) {
      case "Channel Name":
        output = channel.name;
        break;
      case "Channel URL":
        if (channel.guild) {
          output = `https://discord.com/channels/${channel.guild.id}/${channel.id}`;
        } else {
          output = `https://discord.com/channels/@me/${channel.recipient.id}`;
        }
        break;
      case "Channel Topic":
        output = channel.topic || "";
        break;
      case "Channel ID":
        output = channel.id;
        break;
      case "Channel Guild":
        output = channel.guild
        break;
      case "Channel Category":
        output = channel.parent
        break;
      case "Channel Creation Date":
        output = channel.createdAt.getTime()
        break
      case "Channel Is NSFW?":
        output = channel.nsfw;
        break
      case "Channel Slowmode (Seconds)":
        output = channel.rateLimitPerUser;
        break
      case "Channel Position":
        output = channel.position;
        break
      case "Channel Type":
        let channelTypes = {
          0: "Text",
          1: "Private",
          10: "Announcement Thread",
          11: "Public Thread",
          12: "Private Thread",
          13: "Stage",
          14: "Directory",
          15: "Forum",
          16: "Media",
          2: "Voice",
          3: "Group",
          4: "Category",
          5: "Annoncement",
        }

        output = channelTypes[channel.type] || "Unknown"
        break
      case "Webhook List":
        output = await channel.getWebhooks();
        break
    }

    bridge.store(values.store, output)
  },
};
