const { Role } = require("oceanic.js");

module.exports = {
  category: "Roles",
  data: {
    name: "Get Role Info",
    role: {type: "mentioned", value: ""}
  },
  UI: [
    {
      element: "role",
      name: "Role",
      storeAs: "role",
    },
    "-",
    {
      element: "halfDropdown",
      storeAs: "get",
      name: "Get",
      choices: [
        {
          name: "Name"
        },
        {
          name: "Guild"
        },
        {
          name: "ID"
        },
        {
          name: "Color"
        },
        {
          name: "Position"
        },
        {
          name: "Members List"
        }
      ]
    },
    "-",
    {
      element: "store",
      storeAs: "store"
    }
  ],
  
  compatibility: ["Any"],
  subtitle: (values, constants) => {
    return `${values.get} of ${constants.role(values.role)} - Store As: ${constants.variable(values.store)}`
  },
  

  async run(values, message, client, bridge) {    
    /**
     * @type {Role}
     */
    let role = await bridge.getRole(values.role);

    let output;
    switch (values.get) {
      case "Name":
        output = role.name;
        break;
      case "Guild":
        output = role.guild;
        break;
      case "ID":
        output = role.id;
        break;
      case "Color":
        output = role.color.toString(16);
        break;
      case "Position":
        output = role.position;
        break;
      case "Members List":
        output = (await require('./getGuildInfo').getMembers(bridge)).filter(m => m.roles.includes(role.id));
        break;
    }

    bridge.store(values.store, output)
  },
};
