module.exports = {
  data: {
    name: "Get Category Info",
  },
  category: "Channels",
  UI: [
    {
      element: "var",
      storeAs: "category",
      name: "Category"
    },
    "-",
    {
      element: "halfDropdown",
      storeAs: "get",
      name: "Get",
      choices: [
        {
          name: "Name"
        },
        {
          name: "ID"
        },
        {
          name: "Guild"
        },
        {
          name: "Channel List"
        },
        {
          name: "Position"
        }
      ]
    },
    "-",
    {
      element: "storage",
      storeAs: "store"
    }
  ],
  compatibility: ["Any"],

  subtitle: (values, constants) => {
    return `${values.get} of ${constants.variable(values.category)} - Store As: ${constants.variable(values.store)}`
  },

  async run(values, message, client, bridge) {
    let category = await bridge.get(values.category);

    let output;
    switch (values.get) {
      case "Name":
        output = category.name;
        break;
      case "ID":
        output = category.id;
        break;
      case "Guild":
        output = category.guild
        break;
      case "Channels":
        output = category.channels.map((cid, c) => c);
        break;
      case "Channel List":
        output = category.channels.map((cid, c) => c);
        break;
      case "Position":
        output = category.position;
        break;
    }

    bridge.store(values.store, output)
  },
};
