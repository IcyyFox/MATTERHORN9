module.exports = {
  data: {
    name: "Change Server",
  },
  category: "Guilds",
  UI: [
    {
      element: "var",
      storeAs: "guild",
      also: {
        command: "Command Guild",
        id: "Guild ID"
      },
      and: {
        command: false
      },
      name: "Server"
    }
  ],

  compatibility: ["Any"],

  subtitle: (values, constants) => {
    if (values.guild.type == 'command') {
      return `To Command Guild`
    } else if (values.guild.type == 'id') {
      return `To Guild ID (${values.guild.value})`
    } else {
      return `To ${constants.variable(values.guild)}`
    }
  },
  async run(values, message, client, bridge) {
    let guild;
    if (values.guild.type == 'command') {
      guild = message.guild;
    } else if (values.guild.type == 'id') {
      guild = client.guilds.get(bridge.transf(values.guild.value))
    } else {
      guild = await bridge.get(values.guild)
    }

    bridge.guild = guild;
  },
};
