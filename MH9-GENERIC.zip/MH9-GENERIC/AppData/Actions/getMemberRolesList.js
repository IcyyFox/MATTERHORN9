module.exports = {
  data: { name: "Get Member Roles List" },
  category: "Members",
  UI: [
    {
      element: "memberInput",
      storeAs: "member",
      name: "Member"
    },
    "-",
    {
      element: "dropdown",
      name: "Get List Of Member's Roles",
      storeAs: "get",
      choices: [
        {
          name: "IDs"
        },
        {
          name: "Variables"
        }
      ]
    },
    "-",
    {
      element: "storage",
      name: "Store List As",
      storeAs: "store"
    },
  ],

  compatibility: ["Any"],
  subtitle: (values, constants) => {
    return `Store ${constants.user(values.member)} Roles ${values.get} As ${constants.variable(values.store)}`
  },
  async run(values, interaction, client, bridge) {
    let member = (await bridge.getUser(values.member)).member;

    let output = [];
    for (let role in member.roles) {
      console.log(member.guild.roles)
      if (values.get == "IDs") {
        output.push(member.roles[role]);
      } else if (values.get == "Variables") {
        output.push(member.guild.roles.get(member.roles[role]));
      }
    }

    bridge.store(values.store, output);
  },
};
