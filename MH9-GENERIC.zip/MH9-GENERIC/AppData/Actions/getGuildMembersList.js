module.exports = {
  category: "Members",
  data: { name: "Get Guild Members List" },
  UI: [
    {
      element: "halfDropdown",
      name: "Get List Of Guild Members",
      storeAs: "get",
      choices: [
        {
          name: "IDs"
        },
        {
          name: "Variables"
        },
        {
          name: "Usernames"
        }
      ]
    },
    "-",
    {
      element: "storage",
      name: "Store List As",
      storeAs: "store"
    },
  ],

  subtitle: (values, constants) => {
    return `Store Member ${values.get} As ${constants.variable(values.store)}`
  },

  getMembers: async (bridge, get) => {
    let output = []
    const limit = 1000;

    async function push(members, get) {
      for (let member of members) {
        if (get == "IDs") {
          output.push(member.id);
        } else if (get == "Variables" || get == undefined) {
          output.push(member);
        } else {
          output.push(member.username);
        }
      };

      if (members.length == limit) {
        await push((await bridge.guild.getMembers({limit, after: members[members.length - 1].id})), get);
      }
    }

    let firstPage = await bridge.guild.getMembers({limit}, get);
    await push(firstPage, get);

    return output;
  },

  async run(values, interaction, client, bridge) {
    let output = await this.getMembers(bridge, values.get);

    bridge.store(values.store, output)
  },
};
