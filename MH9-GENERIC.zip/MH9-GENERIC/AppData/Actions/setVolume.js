module.exports = {
  data: {
    name: "Set Volume",
  },
  category: "Music",
  UI: [
    {
      name: "Volume",
      element: "input",
      placeholder: "Min: 0 - Max: 100",
      storeAs: "volume"
    }
  ],
  subtitle: (data, constants) => {
    return `To ${data.volume}`;
  },
  async run(values, message, client, bridge) {
    let utilities = bridge.getGlobal({
      class: "voice",
      name: bridge.guild.id,
    });

    utilities.audio.volume.setVolume(Number(bridge.transf(values.volume)))
  },
};
