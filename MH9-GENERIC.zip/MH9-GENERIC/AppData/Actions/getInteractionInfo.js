const { Interaction, InteractionTypes } = require("oceanic.js");

module.exports = {
  data: {name: "Get Interaction Info"},
  category: "Interactions",
  UI: [
    {
      element: "interaction",
      storeAs: "interaction",
    },
    "_",
    {
      element: "toggle",
      storeAs: "replyToInteraction",
      name: "If Possible, Use The Current Interaction"
    },
    "-",
    {
      element: "halfDropdown",
      name: "Get",
      storeAs: "get",
      choices: [
        {
          name: "Author",
        },
        {
          name: "Timestamp"
        },
        {
          name: "ID"
        },
        {
          name: "Message"
        },
        {
          name: "Name"
        }
      ]
    },
    "-",
    {
      element: "store",
      storeAs: "store"
    }
  ],

  compatibility: ["Any"],

  subtitle: (values, constants) => {
    return `${values.get} of ${constants.interaction(values.interaction)} - Store As: ${constants.variable(values.store)}`
  },
  async run(values, message, client, bridge) {
    /**
     * @type {Interaction}
     */
    var interaction = await bridge.getInteraction(values.interaction)
    
    let replyInteraction = bridge.getTemporary({class: "interactionStuff", name: "current"});
    if (values.replyToInteraction && replyInteraction?.getOriginal) {
      interaction = replyInteraction;
    }

    let output;

    switch (values.get) {
      case 'ID':
        output = interaction.id;
        break
      case 'Author':
        output = interaction.user;
        break
      case 'Timestamp':
        output = interaction.createdAt;
        break
      case 'Message':
        output = interaction.message;
        break
      case 'Name':
        output = (interaction.data.name || interaction.name);
        break
      case 'Type':
        let typeMap = {
          [InteractionTypes.APPLICATION_COMMAND]: "Command",
          [InteractionTypes.MESSAGE_COMPONENT]: "Message Component",
          [InteractionTypes.MODAL_SUBMIT]: "Modal Submit",
          [InteractionTypes.PING]: "Ping",
        }

        output = typeMap[interaction.type];
        break
    }
    
    bridge.store(values.store, output)
  },
};
