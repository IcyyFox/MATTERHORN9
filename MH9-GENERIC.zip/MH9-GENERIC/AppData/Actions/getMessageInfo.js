const {Message} = require('oceanic.js')

module.exports = {
  category: "Messages",
  data: {
    name: "Get Message Info"
  },

  UI: [
    {
      element: "message",
      name: "Message",
      storeAs: "message",
    },
    "-",
    {
      element: "halfDropdown",
      storeAs: "get",
      name: "Get",
      choices: [
        {
          name: "Content"
        },
        {
          name: "Author"
        },
        {
          name: "Channel"
        },
        {
          name: "Link"
        },
        {
          name: "Poll"
        },
        {
          name: "Timestamp"
        },
        {
          name: "Guild"
        },
        {
          name: "ID"
        },
        {
          name: "Reactions List"
        },
        {
          name: "Replied To Message"
        },
        {
          name: "Is DM?"
        },
        {
          name: "Embed List"
        },
        {
          name: "Attachment URL List"
        },
        {
          name: "Attachment Name List"
        },
        {
          name: "Was Crossposted?"
        },
        {
          name: "Interaction"
        }
      ]
    },
    "-",
    {
      element: "store",
      storeAs: "store"
    }
  ],

  compatibility: ["Any"],
  subtitle: (values, constants) => {
    return `${values.get} of ${constants.message(values.message)} - Store As: ${constants.variable(values.store)}`
  },


  async run(values, message, client, bridge) {
    /**
     * @type {Message}
     */
    let msg = await bridge.getMessage(values.message)

    let result;
    switch (values.get) {
      case "Content":
        result = msg.content;
        break;
      case "Channel":
        result = msg.channel;
        break;
      case "Author":
        result = msg.author;
        break;
      case "ID":
        result = msg.id;
        break;
      case "Timestamp":
        var cat = `${JSON.parse(JSON.stringify(msg)).createdAt}`;
        result = cat;
        break;
      case "Link":
        result = msg.jumpLink;
        break;
      case "Reactions List":
        let endList = [];
        let gotten = {};
        let reactions = msg.reactions;
        for (let reaction in reactions) {
          let endCount = reactions[reaction].count;
          while (endCount != 0) {
          let reactionList = await msg.getReactions(reaction, {limit: Infinity})
          if (!gotten[reaction]) {
            gotten[reaction] = 0;
          }
          endList.push({
            emoji: reaction.includes(":") ? reaction.split(':')[0] : reaction,
            emojiID: reaction.includes(":") ? reaction.split(':')[1] : '',
            author: reactionList[gotten[reaction]],
            message: msg
          })
          gotten[reaction] = Number(gotten[reaction]) + 1
          endCount--
        }
      }
        result = endList;
        break;
      case "Replied To Message":
        result = msg.referencedMessage;
        break
      case "Guild":
        result = msg.guild;
        break
      case "Is DM?":
        result = msg.inDirectMessageChannel()
        break
      case "Attachment URL List":
        result = msg.attachments.map(attachment => attachment.url)
        break
      case "Attachment Name List":
        result = msg.attachments.map(attachment => attachment.filename)
        break
      case "Embed List":
        result = msg.embeds;
        break
      case "Interaction":
        result = msg.interactionMetadata;
        break
      case "Poll":
        result = msg.poll;
        break
    }

    bridge.store(values.store, result)
  },
};
