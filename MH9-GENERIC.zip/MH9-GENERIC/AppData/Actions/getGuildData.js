module.exports = {
    data: { name: "Get Guild Data" },
    category: "Guild Data",
    UI: [
        {
            element: "input",
            storeAs: "dataName",
            name: "Data Name"
        },
        "-",
                {
            element: "input",
            name: "Default Value",
            storeAs: "defaultValue"
        },
        "-",
        {
            element: "store",
            storeAs: "store"
        }
    ],
    compatibility: ["Any"],
    subtitle: (values, constants) => {
        return `Data Name: ${values.dataName} - Store As: ${constants.variable(values.store)}`
    },
   async run(values, message, client, bridge) {
        let guild = bridge.guild;
        var storedData = bridge.data.IO.get();

        let guildData = '';

        if (values.defaultValue) {
            guildData = bridge.transf(values.defaultValue)
        }

        try {
            if (storedData.guilds[guild.id][bridge.transf(values.dataName)]) guildData = storedData.guilds[guild.id][bridge.transf(values.dataName)];
        } catch (error) {
            storedData.guilds[guild.id] = {}
            bridge.data.IO.write(storedData)
        }

        bridge.store(values.store, guildData)
    }
}