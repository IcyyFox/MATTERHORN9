const { PublicThreadChannel, Message, Base } = require("oceanic.js");

module.exports = {
  data: { name: "Get Thread Info" },
  category: "Threads",
  UI: [
    {
      element: "channel",
      storeAs: "thread",
      excludeUsers: true,
      name: "Thread"
    },
    "-",
    {
      element: "dropdown",
      storeAs: "get",
      name: "Get",
      choices: [
        {
          name: "Member Count"
        },
        {
          name: "Message Count"
        },
        {
          name: "Owner"
        },
        {
          name: "Parent Channel"
        },
        {
          name: "Parent Message"
        },
        {
          name: "Type"
        },
        {
          name: "Applied Tags"
        }
      ]
    },
    "-",
    {
      element: "store",
      storeAs: "store"
    }
  ],

  subtitle: (values, constants) => {
    return `${values.get} of ${constants.variable(values.thread)} - Store As: ${constants.variable(values.store)}`
  },
  
  compatibility: ["Any"],
  
  async run(values, message, client, bridge) {
    
    /**
     * @type {PublicThreadChannel}
     */
    let thread = await bridge.getChannel(values.thread)

    let result;

    switch (values.get) {
      case 'Member Count':
        result = thread.memberCount;
        break
      case 'Owner':
        result = await client.rest.users.get(thread.ownerID);
        break
      case 'Parent Channel':
        result = thread.parent;
        break
      case 'Parent Message':
        result = await thread.getMessage(thread.id)
        break
      case 'Message Count':
        result = thread.messageCount;
        break
      case 'Type':
        let threadTypes = {
          10: "Announcement Thread",
          12: "Private Thread",
          11: "Public Thread"
        }
        result = threadTypes[thread.type];
        break
      case 'Applied Tags':
        result = thread.appliedTags;
        break
    }

    bridge.store(values.store, result)
  },
};
