module.exports = {
  data: {
    name: "Remove Member From Thread",
  },
  category: "Threads",
  UI: [
    {
      element: "memberInput",
      storeAs: "member",
      name: "Member"
    },
    "-",
    {
      element: "var",
      storeAs: "thread",
      name: "Thread Variable"
    }
  ],

  compatibility: ["Any"],
  subtitle: (data) => {return `Thread Variable: ${data.thread.value}`},

  async run(values, message, client, bridge) {
    let thread = await bridge.get(values.thread);

    thread.removeMember(await bridge.getUser(values.member).id)
  },
};
