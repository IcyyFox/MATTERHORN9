const { Client, VoiceChannel } = require("oceanic.js");

module.exports = {
  category: "Channels",
  data: {
    name: "Get Voice Channel Info",
  },
  UI: [
    {
      element: "channelInput",
      storeAs: "channel",
      excludeUsers: true
    },
    "-",
    {
      element: "dropdown",
      storeAs: "get",
      name: "Get",
      choices: [
        {
          name: "Name"
        },
        {
          name: "URL"
        },
        {
          name: "Connected Members List"
        },
        {
          name: "ID"
        },
        {
          name: "Topic"
        },
        {
          name: "Guild"
        },
        {
          name: "Category"
        },
        {
          name: "Creation Date"
        },
        {
          name: "Is NSFW?"
        },
        {
          name: "Slowmode (Seconds)"
        },
        {
          name: "Position"
        }
      ]
    },
    "-",
    {
      element: "storage",
      storeAs: "store"
    }
  ],
  compatibility: ["Any"],

  subtitle: (values, constants) => {
    return `${values.get} of ${constants.channel(values.channel)} - Store As: ${constants.variable(values.store)}`
  },

  

    /**
     * @param {Client} client
     */
    async run(values, message, client, bridge) {
      
    /**
     * @type {VoiceChannel}
     */
    let channel = await bridge.getChannel(values.channel)

    let output;
    switch (values.get) {
      case "Name":
        output = channel.name;
        break;
      case "URL":
        output = `https://discord.com/channels/${channel.guild.id}/${channel.id}`;
        break;
      case "Topic":
        output = channel.topic || "";
        break;
      case "ID":
        output = channel.id;
        break;
      case "Guild":
        output = channel.guild
        break;
      case "Category":
        output = channel.parent
        break;
      case "Creation Date":
        output = channel.createdAt.getTime()
        break;
      case "Is NSFW?":
        output = channel.nsfw;
        break;
      case "Slowmode (Seconds)":
        output = channel.rateLimitPerUser;
        break;
      case "Position":
        output = channel.position;
        break;
      case "Connected Members List":
        let ids = bridge.guild.voiceStates.filter(state => state.channelID == channel.id).map(state => state.userID);
        output = [];

        for (let i in ids) {
          let newOutput = await bridge.getUser({ type: "id", value: ids[i] });
          output.push(newOutput); 
        }
        break;
    }

    bridge.store(values.store, output)
  },
};
