module.exports = {
  data: {
    name: "Split Text",
  },

  category: "Text",

  UI: [
    {
      element: "input",
      name: "Text",
      storeAs: "text",
    },
    "-",
    {
      element: "input",
      name: "Split On",
      storeAs: "splitOn",
    },
    "-",
    {
      element: "storageInput",
      name: "Store Result As",
      storeAs: "store",
    },
  ],
  subtitle: "Split Text: $[text]$",
  compatibility: ["Any"],

  async run(values, message, client, bridge) {
    const text = bridge.transf(values.text);
    const splitOn = bridge.transf(values.splitOn);

    const result = text.split(splitOn);
    bridge.store(values.store, result);
  },
};
