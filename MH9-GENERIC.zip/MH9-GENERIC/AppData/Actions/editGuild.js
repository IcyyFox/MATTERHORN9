module.exports = {
  data: {
    name: "Edit Guild",
    rules: {value: "", type: "unmodified"}
  },
  category: "Guilds",
  UI: [
    {
      name: "Name",
      element: "dropdown",
      storeAs: "guildName",
      extraField: "newName",
      choices: [
        {
          name: "Don't Change"
        },
        {
          name: "Change",
          field: true,
          placeholder: "New Name"
        }
      ]
    },
    "-",
    {
      name: "Rules Channel",
      element: "channel",
      storeAs: "rules",
      optional: true,
      additionalOptions: {
        unmodified: { name: "Don't Change", field: false },
      }
    },
    "_",
    {
      name: "Boost Level Progress Bar",
      element: "dropdown",
      storeAs: "premiumProgressBar",
      choices: [
        {
          name: "Don't Change"
        },
        {
          name: "Show"
        },
        {
          name: "Don't Show"
        }
      ]
    },
    {
      name: "Explicit Content Filtering",
      element: "dropdown",
      storeAs: "filteringLevel",
      choices: [
        {
          name: "Don't Change"
        },
        {
          name: "Disable"
        },
        {
          name: "Members Without Roles"
        },
        {
          name: "All Members"
        }
      ]
    },
    "-",
    {
      element: "input",
      name: "Reason",
      storeAs: "reason",
      placeholder: "Optional"
    }
  ],

  compatibility: ["Any"],
  subtitle: "Reason: $[reason]$",

  async run(values, message, client, bridge) {
    let guild = bridge.guild;

    let editParameters = {};

    switch (values.filteringLevel) {
      case 'Disable':
        editParameters.explicitContentFilter = null
        break
      case 'Members Without Roles':
        editParameters.explicitContentFilter = 1
        break
      case 'All Members':
        editParameters.explicitContentFilter = 2
        break
    }

    switch (values.premiumProgressBar) {
      case 'Show':
        editParameters.explicitContentFilter = true
        break
      case 'Don\'t Show':
        editParameters.explicitContentFilter = false
        break
    }

    if (values.rules.type != 'unmodified') {
      if (values.rules.type == 'None') {
        editParameters.rulesChannelID = null
      } else {
        let rules = await bridge.getChannel(values.rules)
        editParameters.rulesChannelID = rules.id;
      }
    }

    if (values.guildName == 'Change') {
      editParameters.name = bridge.transf(values.newName)
    }

    if (values.reason.trim() != '') {
      editParameters.reason = bridge.transf(values.reason)
    }

    await guild.edit(editParameters)
  },
};
