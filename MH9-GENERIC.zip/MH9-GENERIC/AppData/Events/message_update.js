module.exports = {
  name: "Message Update",
  nameSchemes: ["Store Old Message As", "Store New Message As"],
  initialize(client, data, run) {
    const { Message, RawMessage } = require('oceanic.js');
    client.on('messageUpdate', (updated, old) => {
      run([
        (new Message(old, client)),
        updated
      ], updated)
    })
  }
};