module.exports = {
  name: "Bot Leave Guild",
  nameSchemes: ["Store Guild As"],
  initialize(client, data, run) {
    client.on('guildDelete', (guild) => {
      run([
        guild
      ], {guild})
    })
  }
};
