module.exports = {
  name: "Bot Ready",
  nameSchemes: [],
  initialize(client, data, run) {
    run([], {})
  }
}
