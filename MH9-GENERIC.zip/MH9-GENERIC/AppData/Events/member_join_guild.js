module.exports = {
  name: "Member Join Guild",
  nameSchemes: ["Store Guild As", "Store Member As"],
  initialize(client, data, run) {
    client.on('guildMemberAdd', (member) => {
      run([
        member.guild,
        member
      ], member)
    })
  }
};
