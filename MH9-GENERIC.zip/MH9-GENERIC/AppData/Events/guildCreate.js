module.exports = {
  name: "Bot Join Guild",
  nameSchemes: ["Store Guild As"],
  initialize(client, data, run) {
    client.on('guildCreate', (guild) => {
      run([
        guild
      ], {guild})
    })
  }
};
